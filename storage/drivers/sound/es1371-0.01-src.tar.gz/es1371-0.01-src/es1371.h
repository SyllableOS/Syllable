static int es1371_dsp_open ();
